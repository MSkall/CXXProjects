# Quaternions and Vectors

Program calculates quaternion based on user input of degrees and a 3D vector.

## How to Run

Download files in this folder.

Call `make`.

Run the program with `./main`
